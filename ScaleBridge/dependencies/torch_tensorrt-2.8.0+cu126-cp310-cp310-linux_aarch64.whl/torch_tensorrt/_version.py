__version__ = "2.8.0+cu126"
__cuda_version__ = "12.6"
__tensorrt_version__ = "10.12.0"
